-----------------------------------------
--  Setup Variable Names    
-----------------------------------------

SpellInfo = {}
SpellInfo.constants = {}
SpellInfo.constants.specs = {}
SpellInfo.constants.spells = {}
SpellInfo.constants.start = {}
SpellInfo.constants.finish = {}
SpellInfo.constants.groups = {}

local c = SpellInfo.constants
local specs = SpellInfo.constants.specs
local spells = SpellInfo.constants.spells
local start = SpellInfo.constants.start
local finish = SpellInfo.constants.finish
local groups = SpellInfo.constants.groups

----------------------------------------
-- Spell Groups 
----------------------------------------

groups.raid = {name = "raid", title = "Healing Cooldowns" }
groups.external = {name = "external", title = "External Cooldowns"}
groups.res = {name = "res", title = "Ressurection Spells" }

---------------------------------------
--  Spells
---------------------------------------
-- group = 
-- len = Spell Duration
-- cd = Cooldown time
-- start | finish = 
-- soundfile = name of the mp3

-- Death Knight
	-- Raise Ally
	spells[61999] = {group1 = "res", len=3, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='RaiseAlly'}

-- Demon Hunter
	-- Darkness
	spells[196718] = {group1 = "raid", len=8, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='Darkness'}

--Druid
	-- Tranq!
	spells[740] = {group1 = "raid", len=8, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="Tranquility"}
	-- IronBark
	spells[102342] = {group1 = "external", len=12, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="Ironbark"}
	-- Rebirth
	spells[20484] = {group1 = "res", len=3, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="Rebirth"}
	-- Innervate
	spells[29166] = {group1 = "raid", len=12, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="Innervate"}

-- Hunter
-- Mage

-- Monk
	-- Life Cocoon
	spells[116849] = {group1 = "external", len=12, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="LifeCocoon"}
	-- Revival
	spells[115310] = {group1 = "raid", len=3, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", soundfile="Revival", soundfile='Revival'}

-- Paladin
	-- Aegis of Light
	spells[204150] = {group1 = "raid", len=6, cd=300, mt=true, start='SPELL_CAST_SUCCESS', finish='SPELL_AURA_REMOVED', soundfile='AegisofLight'}
	-- Aura Mastery
	spells[31821] = {group1 = "raid", len=8, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="DevotionAura"}
	-- Blessing of Sacrifice
	spells[6940] = {group1 = "external", len=12, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="HandofSac"}
	-- Blessing of Spellwarding
	spells[204018] = {group1 = "raid", len=10, cd=180, mt=false, start='SPELL_CAST_SUCCESS', finish="SPELL_AURA_REMOVED", soundfile="SpellWarding"}
	-- Blessing of Protection
	spells[1022] = {group1="raid", len=10, cd=300, mt=false, start="SPELL_CAST_SUCCESS", finish='SPELL_AURA_REMOVED', soundfile='BlessingofProtection'}

-- Priest
	-- Divine Hymn
	spells[64843] = {group1 = "raid", len=8, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='DivineHymn'}
	-- Power Word Barrier
	spells[62618] = {group1 = "raid", len=10, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='PWB'}
	-- Vampiric Embrace
	spells[15286] = {group1 = "raid", len=15, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='VampiricEmbrace'}
	-- Pain Suppression
	spells[33206] = {group1 = "external", len=8, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='PainSuppression'}
	-- Guardian Spirit
	spells[47788] = {group1 = "external", len=10, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='GuardianSpirit'}
	-- Symbol of Hope
	spells[64901] = {group1 = "raid", len=6, cd=360, mt=true, start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='SymbolofHope'}

-- Rogue
	
-- Shaman 
	-- AG
	spells[108281] = {group1 = "raid", len=10, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="AncestralGuidance"}
	
	-- HTT
	spells[108280] = {group1 = "raid", len=10, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", soundfile="HealingTideTotem"}
	
	-- Spirit Link
	spells[98008] = {group1 = "raid", len=6, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", soundfile="SpiritLinkTotem"}

-- Warrior
	--Rally
	spells[97462] = {group1 = "raid", len=10, cd=180, mt=true,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile='RallyingCry'}

--Warlock
	--soulstone
	spells[20707] = {group1 = "res", len=3, cd=180, mt=false,  start="SPELL_CAST_SUCCESS", finish="SPELL_AURA_REMOVED", soundfile="Soulstone"}


