------------------------------------
--  Setup Variable names          --
------------------------------------
local SWRaidCD = LibStub("AceAddon-3.0"):NewAddon("SWRaidCD", "LibBars-1.0", "AceEvent-3.0", "AceConsole-3.0") 
local version = GetAddOnMetadata("SWRaidCD", "Version")
if version:match("@") then
	version = "Development"
end
--add localization
SWRaidCD.L = L
--decare the database
local db

local inDebug = false

--------------------------------------
-- Additional Libraries
--------------------------------------
local Media = LibStub:GetLibrary("LibSharedMedia-3.0")
local DataBroker = LibStub:GetLibrary("LibDataBroker-1.1")
local Bars = LibStub:GetLibrary("LibBars-1.0")
Media:Register("statusbar", "Blizzard", [[Interface\TargetingFrame\UI-StatusBar]])

-------------------------------------
-- Spell info for bars
-------------------------------------
local c = SpellInfo.constants;
local specs = SpellInfo.constants.specs;
local start = SpellInfo.constants.start;
local finish = SpellInfo.constants.finish;
local spells = SpellInfo.constants.spells;
local groups = SpellInfo.constants.groups;
local localclasses = {}
local skins = {}


local activebars = {}
local activeanchor = {}
local available = {}
local cooldowns = {}
local sortedcooldowns = {}
local GetTime = GetTime

-------------------------------------
-- Setup some defaults
-------------------------------------
local defaults = {
	profile = {
		barHeight = 20,
		barWidth = 300, 
		enableAddon = true, 
		enableSound=true,
		horizontalOrientation = "RIGHT",
		maxBars = 10,
		scale = 1.0,
		hideAnchor = false,
		BarX = 400,
		BarY = 400,
		fontFlags = "NONE", 
		fontScale = 12, 
		fontType = "Friz Quadrata TT", 
		BarBorder = "None", 
		BarTexture = "Blizzard", 
     	BarsColour = { r = 0, g = 1, b = 0, a = 1 },
     	borderThickness = 10,
     	BarsAlpha = 1,
     	BarsIcon = true,
     	reverseGrowth=false,
     	showBattleRes = true
	}
}

-----------------------------------------
-- Setup the addon 
-----------------------------------------
function SWRaidCD:OnInitialize()
	if inDebug then
		print("SWRaidCD:OnInitialize()")
	end
	--register saved variaables
	db = LibStub("AceDB-3.0"):New("SWRaidCDDB", defaults, true)
	db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	db.RegisterCallback(self, "OnProfileReset", "OnNewProfile")
	db.RegisterCallback(self, "OnNewProfile", "OnNewProfile")
	self.db = db
	self:SetEnabledState(self.db.profile.enableAddon)
	
	--addon options table
	self.options = OptionsTable(self)
	-- add profiles
	self.options.args.profilesTab = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)
	self.options.args.profilesTab.order = 50

	--Register options
	LibStub("AceConfig-3.0"):RegisterOptionsTable("SWRaidCD", self.options)
	--Add to Blizzard Window
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("SWRaidCD", "SWRaidCD")

	-- auto expand the sub-panels
	do 
		self.optionsFrame:HookScript("OnShow", function(self)
			if InCombatLockdown() then return end
			local target = self.parent or self.name
			local i = 1
			local button = _G["InterfaceOptionsFrameAddonsButton"..i]
			while button do
				local element = button.element
				if element.name == target then
					if element.hasChildren and element.collapsed then
						_G["InterfaceOptionsFrameAddonsButton"..i.."Toggle"]:Click()
					end
					return
				end
				i = i + 1
				button = _G["InterfaceOptionsFrameAddonsButton"..i]
			end
		end)
		local function OnClose(self)
			if inDebug then
				print("OnClose(self)")
			end
			if InCombatLockdown() then return end
			local target = self.parent or self.name
			local i = 1
			local button = _G["InterfaceOptionsFrameAddonsButton"..i]
			while button do
				local element=button.element
				if element.name == target then
					if element.hasChildren and not element.collapsed then 
						local selection = InterfaceOptionsFrameAddons.selection
						if not selection or selection.parent ~= target then
							_G["InterfaceOptionsFrameAddonsButton"..i.."Toggle"]:Click()
						end
					end
					return
				end
				i= i +1
				button = _G["InterfaceOptionsFrameAddonsButton"..i]
			end
		end
		hooksecurefunc(self.optionsFrame, "okay", OnClose)
		hooksecurefunc(self.optionsFrame, "cancel", OnClose)
	end

	--add console commands
	self:RegisterChatCommand("sw", "SlashHandler")
	self:RegisterChatCommand("swraidcd", "SlashHandler")

	--Create DataBroker
	if DataBroker then
		local launcher = DataBroker:NewDataObject("SWRaidCD", {
			type = "launcher",
			OnClick = function(clickedframe, button)
				if button == "LeftButton" then
					self.db.profile.hideAnchor = not self.db.profile.hideAnchor
					if self.db.profile.hideAnchor then
						self.RaidCD_group.HideAnchor()
						self.RaidCD_group.Lock()
					else
						self.RaidCD_group.ShowAnchor()
						self.RaidCD_group.Unlock()
						self.RaidCD_group.SetClampedToScreen(true)
					end
					LibStub("AceConfigRegistry-3.0"):NotifyChange("SWRaidCD")
				elseif button == "RightButton" then
					InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
				elseif button == "Middle Button" then
					self:StartTestBars()
				end
			end,
			OnTooltipShow = function(self)
				GameTooltip:AddLine("SWRaidCD".." "..version, HIGHLIGHT_FONT_COLOR.r, HIGHLIGHT_FONT_COLOR.g, HIGHLIGHT_FONT_COLOR.b)
				GameTooltip:AddLine("Left Click to lock/unlock bars. Right click for Config.\n Middle click for Test Bars.", NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b)
				GameTooltip:Show()
			end
		})
		self.launcher = launcher
	end

	--------------------------------------
	-- Build tables 
	--------------------------------------

	for k,v in pairs(spells) do 
		--icons and names

		local name, _, icon = GetSpellInfo(k)
		if inDebug then
			print(name, icon)
		end

		if (not v.name) then -- allow a custom name
			v.name = name;
		end
		if (not v.icon) then -- custom icon
			v.icon = icon;
		end
		v.id = k;
		if v.group1 == 'raid' then
			v.group = 'raid'
		elseif v.group1 == 'res' then 
			v.group = 'res'
		elseif v.group1 == 'external' then
			v.group = 'external'
		end
		
		--localize talent names
		if (v.talents) then 
			for tid, t in pairs(v.talents) do 
				local name = GetSpellInfo(tid);
				if (not t.name) then 
					t.name = name;
				end
			end
		end
	
		if (v.glyphs) then 
			for gid, g in pairs(v.glyphs) do
				local name = GetSpellInfo(gid)
				if (not g.name) then 
					g.name = name;
				end
			end
		end
	
		if (v.thetalent) then
			local name = GetSpellInfo(v.thetalent);
			v.thetalent = name;
		end
		
		--start and end tables
		if (v.start) then 
			if (not start[v.start]) then start[v.start] = {}; end
			start[v.start][k] = v;		
		end
		if (v.finish) then
			if (not finish[v.finish]) then finish[v.finish] = {}; end
			finish[v.finish][k] = v;
		end
	end

end

function SWRaidCD:OnDisable()
	if inDebug then
		print("SWRaidCD:OnDisable()")
	end
	self:UnregisterAllEvents()
	Media.UnregisterAllCallbacks(self)
	self.RaidCD_group.UnregisterAllCallbacks(self)
end

function SWRaidCD:OnEnable()
	if inDebug then
		print("SWRaidCD:OnEnable()")
	end
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

	--Create the bar groups
	self.RaidCD_group = self.RaidCD_group or SWRaidCD:NewBarGroup("Raid CDs", self.db.profile.horizontalOrientation, 300, 15, "SWRaidCD_bars")
	RaidCD_group = self.RaidCD_group
	self.RaidCD_group:SetClampedToScreen(true)
	if self.db.profile.hideAnchor then
		self.RaidCD_group:HideAnchor()
		self.RaidCD_group:Lock()
	else
		self.RaidCD_group:ShowAnchor()
		self.RaidCD_group:Unlock()
	end

	self.RaidCD_group:SetMaxBars(self.db.profile.maxBars)
	self.RaidCD_group:SetHeight(self.db.profile.barHeight)
	self.RaidCD_group:SetWidth(self.db.profile.barWidth)
	self.RaidCD_group:SetScale(self.db.profile.scale)
	self.RaidCD_group:ReverseGrowth(self.db.profile.reverseGrowth)
	self:RestorePosition()
	Media.RegisterCallback(self, "OnValueChanged", "UpdateMedia")
	self.RaidCD_group.RegisterCallback(self, "AnchorMoved", "SavePosition")
	self.RaidCD_group.RegisterCallback(self, "AnchorClicked")
end

function SWRaidCD:AnchorClicked(callback, group, button)
	if inDebug then
		print("SWRaidCD:AnchorClicked(callback, group, button)", callback, group, button)
	end
	if button == "RightButton" then
		self.RaidCD_group:HideAnchor()
		self.RaidCD_group:Lock()
		self.db.profile.hideAnchor = true
	end
end

function SWRaidCD:SavePosition()
	if inDebug then
		print("SWRaidCD:SavePosition()")
	end
	local f = self.RaidCD_group
	local s = f:GetEffectiveScale()
	self.db.profile.BarX = f:GetLeft()*s
	self.db.profile.BarY = f:GetTop()*s
end

function SWRaidCD:RestorePosition()
	if inDebug then
		print("SWRaidCD:RestorePosition()")
	end
	local x =self.db.profile.BarX
	local y = self.db.profile.BarY
	if not x or not y then return end

	local f = self.RaidCD_group
	local s = f:GetEffectiveScale()
	f:ClearAllPoints()
	f:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x/s, y/s)
end

function SWRaidCD:UpdateMedia(callback, type, handle)
	if inDebug then
		print("SWRaidCD:UpdateMedia(callback, type, handle)", callback, type, handle)
	end
	if type == 'statusbar' then
		self.RaidCD_group:SetTexture(Media:Fetch("statusbar", self.db.profile.BarsTexture))
	elseif type == "border" then
		self.RaidCD_group:SetBackdrop({
			edgeFile = Media:Fetch("border", self.db.profile.BarBorder),
			tile = false,
			tileSize = self.db.profile.scale + 1, 
			edgeSize = self.db.profile.borderThickness,
			insets = {left=0, right=0, top=0, bottom=0}
			})
	elseif type == "font" then 
		self.RaidCD_group:SetFont(Media:Fetch("font", self.db.profile.fontType), self.db.profile.fontScale, self.db.profile.fontFlags)
	end
end
-------------------------------------------
-- Tools for tracking party versus raid
-------------------------------------------
-- process slash commands ---------------------------------------------------
function SWRaidCD:SlashHandler(input)
	if inDebug then
		print("SWRaidCD:SlashHandler(input)", input)
	end
	input = input:lower()
	if input == "test" then
		self:StartTestBars()
	elseif input == "toggle" or input == "anchor" then
		if self.db.profile.hideAnchor == false then
			self.RaidCD_group:HideAnchor()
			self.RaidCD_group:Lock()
			self.db.profile.hideAnchor = true
		else
			self.RaidCD_group:ShowAnchor()
			self.RaidCD_group:Unlock()
			self.RaidCD_group:SetClampedToScreen(true)
			self.db.profile.hideAnchor = false
		end
	elseif input == "grow" then
		if self.db.profile.reverseGrowth == true then 
			value=false
		else
			value = true
		end
		self.db.profile.reverseGrowth = value
		self.RaidCD_group:ReverseGrowth(value)	
	else
		InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
		if not self.optionsFrame:IsVisible() then
			InterfaceOptionsFrame_OpenToCategory(self.optionsFrame)
		end
	end
end

---Generic info for solo/party/raid
local function getgroupUnitInfo(index)
	if inDebug then
		print("getgroupUnitInfo", index)
	end
	local raidN = GetNumGroupMembers()	
	local doReturnSelf = false;
	if (raidN>0) then
		local name, rank, subgroup, level, class, fileName, zone, online, isDead, role, isML = GetRaidRosterInfo(index);
		return name, class, online, isDead, subgroup;
	else
		doReturnSelf=true;
	end	
	if(doReturnSelf) then
		local name = UnitName("player");
		local class = UnitClass("player");
		local online = true;
		local isDead = UnitIsDeadOrGhost("player");
		return name, class, online, isDead, 1
	end
end


-----------------------------------------
-- Manage bars 
-----------------------------------------
local function sortBars()
	if inDebug then
		print("sortBars()")
	end
	local refs = {}
	for k, v in pairs(activebars) do 
		if (v.expires <= GetTime()) then
			activebars[k] = nil;
		else
			table.insert(refs, {expires = v.expires, key=k});
		end
	end
	table.sort(refs, function(a, b) return a.expires < b.expires end);
	for i = 1, getn(refs) do 
		local bar = activebars[refs[i].key].barl
		if (bar) then 
			bar:SetPoint("TOP", activeanchor.frame, "BOTTOM", 0, -db.activebarheight*(i-1))
		else
			activebars[refs[i].key] = nil
		end 
		i = i+1
	end
	refs = nil;
end

--test bars
function SWRaidCD:StartTestBars()
	if inDebug then
		print("SWRaidCD:StartTestBars()")
	end
	if not self.db.profile.enableAddon then return end
	orientation = (db.profile.horizontalOrientation == "RIGHT") and Bars.RIGHT_TO_LEFT or Bars.LEFT_TO_RIGHT

	SWRaidCDDrawNewBar("Test Bar 1", 4, 136107, 0, 'DRUID', "None")                  --Tranq
	SWRaidCDDrawNewBar("Test Bar 2", 5, 135872, 0, "PALADIN", "None")                --Aura Mastery
	SWRaidCDDrawNewBar("Test Bar 3", 6, 1020466, 0, 'MONK', "None")                  --Revival
	SWRaidCDDrawNewBar("Test Bar 4", 7, 237540, 0, 'PRIEST', "None")                 --Divine Hymn
	SWRaidCDDrawNewBar("Test Bar 5", 8, 538569, 0, 'SHAMAN', "None")                 --HTT


end

function SWRaidCDDrawNewBar(title, duration, icon, descriptor, class, soundfile)
	if inDebug then
		print("SWRaidCDDrawNewBar(title, duration, icon, descriptor, class, soundfile)", title, duration, icon, descriptor, class, soundfile)
	end

	bar = RaidCD_group:NewTimerBar(title, title, duration, nil, icon, 0)
	orientation = (db.profile.horizontalOrientation == "RIGHT") and Bars.RIGHT_TO_LEFT or Bars.LEFT_TO_RIGHT
	t = db.profile.BarsColour
	if db.profile.classColours and class ~= nil then
		local c = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[class]
		bar.texture:SetVertexColor(c.r, c.g, c.b, t.a)
	else
		bar.texture:SetVertexColor(t.r, t.g, t.b, t.a)
	end
	bar:SetOrientation(orientation)
	bar:ShowIcon()
	bar:SetFont(Media:Fetch("font", db.profile.fontType), db.profile.fontScale, db.profile.fontFlags)
	bar:SetTexture(Media:Fetch("statusbar", db.profile.BarsTexture))
	bar:SetBackdrop({
		edgefile = Media:Fetch("border", db.profile.BarBorder), 
		tile=true,
		tileSize=db.profile.scale+1, 
		edgeSize=db.profile.borderThickness, 
		insets = {left=0, right=0, bottom=0, top=0}
		})

	activebars[descriptor] = {expires=GetTime()+duration, bar=bar}

	if db.profile.enableSound then 
		local willplay, soundhandle = PlaySoundFile(soundfile, "Master")
	end
end	
-------------------------------------------------------------
-- bars for active cooldowns
-------------------------------------------------------------
local function spellUsed(spell, sourceGUID, targetGUID, sourceName, targetName, duration)
	if inDebug then
		print("DEBUG - In spellUsed(spell, sourceGUID, targetGUID, sourceName, targetName, duration)", spell, sourceGUID, targetGUID, sourceName, targetName, duration)
		print("DEBUG - spell.icon = ", spell.icon)
	end
	local duration = duration or spell.len
	local descriptor = spell.id .. sourceGUID;

	local label;
	local soundfile;

	raidN = GetNumGroupMembers()
	local i = 0
	local isingroup = 0
	
	if (raidN == 0) then 
		member = getgroupUnitInfo(1)
	
		if member == sourceName then isingroup = 1; end
	else
		for i = 0,raidN do
			member = getgroupUnitInfo(i)
			if member == sourceName then isingroup = 1; end
			i = i + 1
		end
	end

	if inDebug then
		print("DEBUG - isingroup = ", isingroup)
	end

	if isingroup == 0 then return; end

	if(spell.mt) then 
		label = spell.name .. " (" .. sourceName .. ")"
	elseif (targetName == nil) then
		label = spell.name .. " (" .. sourceName .. " -> " .. sourceName .. ")"
	else
		label = spell.name .. " (" .. sourceName .. " -> " .. targetName .. ")"
	end
	if(spell.soundfile) then
		soundfile = "Interface\\Addons\\SWRaidCD\\Sounds\\" .. spell.soundfile .. ".mp3";
	end
	
	if inDebug then
		print("DEBUG - In spell used about to call SWRaidCDDrawNewBar(label, duration, spell.icon, descriptor, class, soundfile)")
		print("Debug - ", label, duration, spell.icon, descriptor, class, soundfile)

	end

	local text
	local descriptor = spell.id .. sourceGUID;
	local _, class = UnitClass(sourceName)
	if inDebug then
		print("DEBUG - In spell used about to call SWRaidCDDrawNewBar(label, duration, spell.icon, descriptor, class, soundfile)")
		print("Debug - ", label, duration, spell.icon, descriptor, class, soundfile)

	end
	SWRaidCDDrawNewBar(label, duration, spell.icon, descriptor, class, soundfile)
	
	
end

local function spellFinish(spell, sourceGUID, targetGUID, sourceName, targetName)
	if inDebug then
		print("spellFinish(spell, sourceGUID, targetGUID, sourceName, targetName)", spell, sourceGUID, targetGUID, sourceName, targetName)
	end
	local descriptor = spell.id .. sourceGUID;
	if(activebars[descriptor]) then
		if (activebars[descriptor].expires > GetTime()) then
			RaidCD_group:RemoveBar(activebars[descriptor].bar);
		end
		activebars[descriptor] = nil;
	end
end

---------------------------
-- Spell events
---------------------------

local function SpellCastSuccess( event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)
	if inDebug then
		print("SpellCastSuccess( event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)", event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)
	end
	if ((start[event] ~= nil) and (start[event][spellId] ~= nil)) then
		local spell = start[event][spellId];
		if ((not spell.mt) or event=="SPELL_CAST_SUCCESS" or (spell.mt and targetGUID==sourceGUID)) then
			local spellname, _, _, _, endTime=UnitChannelInfo(sourceName);
			local duration
			if (spellname) then
				duration = endTime/1000.0 - GetTime();
			end
			if (not db.profile.showBattleRes) and (spell.group == 'res') then return; end
			spellUsed(spell, sourceGUID, targetGUID, sourceName, targetName, duration)
		end
	end
end

local function SpellAuraRemoved( event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)
	if inDebug then
		print("SpellAuraRemoved( event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)", event, sourceGUID, targetGUID, sourceName, targetName, spellId, spellName)
	end
	if(finish[event] ~= nil and finish[event][spellId] ~= nil) then
		local spell = finish[event][spellId];
		if(not spell.mt or (spell.mt and targetGUID == sourceGUID)) then
			spellFinish(spell, sourceGUID, targetGUID, sourceName, targetName)
		end
	end
end
	
	
-----------------------------
-- Housekeeping
----------------------------
--User changes profile
function SWRaidCD:OnProfileChanged()
	if inDebug then
		print("SWRaidCD:OnProfileChanged()")
	end
	db = self.db 
end

--New Profile
function SWRaidCD:OnNewProfile()
	if inDebug then
		print("SWRaidCD:OnNewProfile()")
	end
end


------------------------------------
-- Event Handling
------------------------------------
--function SWRaidCD:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
function SWRaidCD:COMBAT_LOG_EVENT_UNFILTERED()
	--if inDebug then
	--	print("SWRaidCD:COMBAT_LOG_EVENT_UNFILTERED(event, ...) test", event)
	--end
	--local timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceraidFlags, targetGUID, targetName, targetFlags = CombatLogGetCurrentEventInfo()
	--local timestamp, Event, _, sourceGUID, _, _, _, _, _, _, _, arg12, _, _, arg15, arg16 = CombatLogGetCurrentEventInfo()

	--[[
	if inDebug then
		--print(event)
		--print(timestamp, type, hideCaster, sourceGUID, sourceName, sourceFlags, sourceraidFlags, targetGUID, targetName, targetFlags)

			for key, value in pairs(logEvent) do
				print('\t', value)
			end
	print("--------------------------------")
	end
	]]--
	--Grabbing from the line in the log.  Note spellID and spellName 
	local _, eventName, _, sourceGUID, sourceName, _, _, destGUID, destName, _, _, spellID, spellName = unpack({CombatLogGetCurrentEventInfo()})
	
	if inDebug then
		print("DEBUG - eventName is: ", eventName)
		print("DEBUG - spellid is: ", spellID)
		print("DEBUG - spellName is: ", spellName)
		print("--------------------------------")
	end
	
	if eventName == "SPELL_CAST_SUCCESS" then 

		SpellCastSuccess(eventName, sourceGUID, destGUID, sourceName, targetName, spellID, spellName);

	elseif eventName == "SPELL_AURA_REMOVED" then 

		SpellAuraRemoved(type, sourceGUID, targetGUID, sourceName, targetName, spellID, spellName); 

	end
		
end
